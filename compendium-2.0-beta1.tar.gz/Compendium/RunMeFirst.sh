# If you are installing over an existing version of Compendium
# there have been some slight filename changes so this will remove the old files so there is no confusion
# Please run this once first
#!/bin/bash
rm license.htm
rm ReadMe.htm
rm compendium.sh
rm -r Skins/Old_Default
rm -r Skins/New_Default
