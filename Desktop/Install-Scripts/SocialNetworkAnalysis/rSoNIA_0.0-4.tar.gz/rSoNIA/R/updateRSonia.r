#downloads and installs the various java libraries and checks 
#that everything is ready to go.     
#Steve has a new puppy named BILLY! 


updateSonia <- function(installerLoc = "http://internap.dl.sourceforge.net/sourceforge/sonia/",
  installerName = "install_sonia_1_1_5.jar",
  
  installDir = rSoniaLoc(), #paste(.Library,"/rSoNIA/java/",sep=""),
  javaDownloadUrl = "http://www.java.com/getjava/index.jsp",
  rsoniaRepos = "http://csde.washington.edu/~skyebend/rsonia/current/",
  dynamicNetworkRepos = "http://csde.washington.edu/~skyebend/dynamicnetwork/current/" ){

   #installerLoc <- "http://www.stanford.edu/group/sonia/";
        #pavel points out that should not assume write access to rSoNIA library
  #should be a way to manage instalation. 

  #check if java is installed 
  print("Checking java version.."); 
  if(.Platform$OS.type=="unix"){
    javaVer <- system("java -version 2>/dev/stdout", intern=TRUE);
  }else{
    javaVer <- system("java -version", intern=TRUE);
  }
  print(javaVer);
  verNum <- as.numeric(substr(javaVer[1],15,17));
  #print(verNum);
  if (is.na(verNum) | !is.numeric(verNum)){
    answer <-readline("java does not seem to be correctly installed, would you like to download it? (y/n)");
    if (substr(answer,1,1) == "y"){
       browseURL(javaDownloadUrl);
        stop("\nPlease re-run updateSonia() after java has been installed\n");
    } else {
     stop("Java must be installed for SoNIA to run");
    }
    } else {
      if (verNum < 1.4) {
       answer <-readline("The version of java must be newer than 1.4, would you like to download a newer version? (y/n)");
    if (substr(answer,1,1) == "y"){
        browseURL(javaDownloadUrl);
        stop("\nPlease re-run updateSonia() after java has been installed\n");
    } else {
     stop("Java must be installed before SoNIA");
    }

       }
  }  
  
  # delete the conents of the lib directory 
  if (file.exists(paste(installDir,"lib",sep=""))){
    print("deleteing old library versions..");
    file.remove(list.files(full=TRUE,paste(installDir,"lib",sep=""))); 
  }   
  #make sure dir exists
  if (file.exists(installDir)){
      file.remove(list.files(full=TRUE,installDir,));
  } else {
    dir.create(installDir,showWarnings=FALSE);
  }
  
  #download the sonia installer
  print ("Downloading sonia web installer...");
  download.file(paste(installerLoc,installerName,sep=""),
    paste(installDir,installerName,sep=""),mode="wb");
  #launch the sonia installer
  launchString <- paste("java -jar ",installDir,installerName," ",installDir,sep="");
  if(.Platform$OS.type=="unix"){
    returnCode <- system(launchString);
  }else{
    returnCode <- system(launchString, show.output.on.console=FALSE);
  }
 # if (returnCode){
 #   print ("SoNIA java libraries have been installed");
  #}
 # else {stop("Error installing SoNIA java libraries")};
  #install the dynamicnetwork package
  print ("checking required package dynamicnetwork");
  #check if is installed
  if (require(dynamicnetwork)){
    ##update.packages("dynamicnetwork", lib=.libPaths()[1], contriburl=dynamicNetworkRepos);
  } else {
  print("missing package dynamicnetwork");
   # install.packages("dynamicnetwork", lib=.libPaths()[1], contriburl=dynamicNetworkRepos);
  }
  
 # check if update was successful
   soniaVer <- list.files(installDir, pattern = "^sonia");
   numLibs <- 0;
   if (file.exists(paste(installDir,"lib",sep=""))){
      numLibs <-   length(list.files(paste(installDir,"lib",sep="")));
   }
    if (length(soniaVer) > 0 & numLibs > 0){
        print("Update  of SoNIA java libraries complete");
        print(paste("Current version:",soniaVer,"with",numLibs," jar libraries"));
    }
    else{
           stop("Update of SoNIA java libraries was NOT successful");
    }
}