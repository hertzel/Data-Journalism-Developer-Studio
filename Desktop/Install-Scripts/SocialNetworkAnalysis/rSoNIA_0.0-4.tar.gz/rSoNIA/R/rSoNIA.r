

launchSonia <- function(network,interactive = TRUE, printLaunch = FALSE,
  time.bounds = get.time.bounds(network),
 max.iter = 500,
  movie.file = NULL,
  movie.type = "mov",
	usearrows = TRUE,
	#mode = "fruchtermanreingold",
	displaylabels = TRUE,
	#edge.col = 1, 
	#label.col = 1,
  vertex.lab = "vertex.names", 
	vertex.col = "red", 
  vertex.x = "0.0",
  vertex.y = "0.0", 
 	#vertex.border = 1,
	vertex.cex = 10,
	vertex.shape = "circle",
	arc.col = "gray",
	layout.type = "MultiComp KK Layout",
	soniaPath = paste(rSoniaLoc(),"sonia_1_1_5.jar",sep=""),
	verbose = FALSE
  )
{
	#check that object has the right type
	if (!is.dynamic(network)){
	   stop("network argument to launchSonia must be a dynamic network");
	}
	
	#check if sonia java components are installed
	if (!file.exists(soniaPath)){
	 stop(paste("Unable to locate SoNIA java files at location specified by soniaPath:",
	 soniaPath,
   " try updateSonia() to run installer for SoNIA java files?",sep="\n"));
	}
	#transform parameters as necessary
	#if it is not the name of a variable, assume it is a color
	if (!vertex.col%in%unique(unlist(sapply(network$val,names)))){
	 vertex.col <- col2rgb(vertex.col); #transform to rgb values
  }
	soniaParseSettings$vertex.color[2] <- paste(vertex.col,sep="\n",collapse=",");
	soniaParseSettings$arc.color[2] <- paste(vertex.col,sep="\n",collapse=",");
	soniaParseSettings$vertex.label[2] <- vertex.lab;
  soniaParseSettings$vertex.size[2]   <- vertex.cex;
  soniaParseSettings$vertex.shape[2]   <- vertex.shape;
  soniaParseSettings$vertex.x[2] <- vertex.x;
  soniaParseSettings$vertex.y[2] <- vertex.y;
  soniaLayoutSettings$slice.start[2] <- time.bounds[1];
  soniaLayoutSettings$slice.end[2] <- time.bounds[2];
  soniaApplySettings$kk.max.passes[2] <- max.iter;
  #change this to allow arg matching
  soniaLayoutSettings$layout.type[2] <- layout.type;
  #arrows and labels options
  if (!displaylabels){
    soniaGraphicsSettings$node.labels[2] <- "none";
  } else {
     #hmm, skips id's option...
     soniaGraphicsSettings$node.labels[2] <- "labels";
  }
  
  if (!usearrows){
    soniaGraphicsSettings$arrow.style[2]<-"none";
  }   else {
      soniaGraphicsSettings$arrow.style[2]<-"arrow at end"
  }
  
  if (!is.null(movie.file)){
    soniaMovieSettings$file.name[2] <- movie.file;
    soniaMovieSettings$file.type[2] <- movie.type;
  } else {
   # if in non-interactive mode, need file name
   if (!interactive){
    stop(" name for movie export (movie.file) must not be NULL");
   }
  }

	netString <- paste(deparse(network,control=NULL),sep=",");
	runBatch <- "";
	if (!interactive){
	  runBatch <- " runbatch: ";
	  if (verbose) {
	  runBatch <-  " runbatch: verbose:"   ;
	  }
	}
	
		batchString <- paste(c(" batchsettings:\"",
		  print(soniaParseSettings),
			print(soniaLayoutSettings),
			print(soniaApplySettings),
			print(soniaGraphicsSettings),
			print(soniaBrowseSettings),
			print(soniaMovieSettings),
			"\""),sep="\n",collapse="\n");
			
			tempFile <- paste(tempfile("network"),".rdump",sep="");
		##	print(tempFile);
			write(netString,file=tempFile,ncolumns=200);
			
  
	launchString <- paste(c("java -Xmx512m -jar ",soniaPath,
		" file:\"",tempFile,"\"",runBatch,batchString),sep="",collapse="");
	
	if (printLaunch){
    print(launchString);
  }
      print("Launching SoNIA as external java application...")
	returnCode <- system(launchString ,intern=TRUE);
	#    show.output.on.console=TRUE,invisible = TRUE
	#check if it returned a warning message
	if (is.character(returnCode)){
	 if (length(returnCode) > 0){
	   print(returnCode);
	   stop("ERROR IN SoNIA export");
	 } else {
	  print("SoNIA export finished.");
	 }
	} 
	#if (returnCode == 0){
	# print("SoNIA export finished");
	#} else {
	#print("ERROR in SoNIA export");
	#}
}

#need to convert TRUE to true for java...

#takes the settings class and puts it in a text form to be read by sonia
print.sonia.settings <- function(x,...){
    	paste(lapply(x,function(x){paste(x[1],x[2],sep="=")}),sep="\n");
}



#for all of these settings objects, the name of the variable can be changed
#to match R's style.  But the first element of the value pair is the
#key used by sonia and can only change if we change the java code. 

soniaParseSettings <- list(
  settings.class=c("SettingsClass","sonia.settings.RParserSettings"),
  vertex.label = c("NODE_LABEL","vertex.names"),
  vertex.color = c("NODE_COLOR","red"),
  vertex.size = c("NODE_SIZE","8"),
  vertex.shape = c("NODE_SHAPE","circle"),
  vertex.x = c("NODE_X","0.0"),
  vertex.y = c("NODE_Y","0.0"),
  arc.color = c("ARC_COLOR","gray")
);
class(soniaParseSettings) <- "sonia.settings";

soniaMovieSettings <- list(
  settings.class=c("SettingsClass","sonia.settings.MovieSettings"),
  file.name = c("OUTPUT_PATH","rNetworkExport"),
  file.type = c("FILE_TYPE","mov"),
  format.params = c("FORMAT_PARAMS","CODEC"),
  qt.codec = c("CODEC","Animation")
  
);
class(soniaMovieSettings) <- "sonia.settings";

 soniaLayoutSettings <- list(
	settings.class=c("SettingsClass","sonia.settings.LayoutSettings"),
	slice.aggregation = c("SLICE_AGGREGATION", "Number  of i->j ties"),
	slice.start = c("SLICE_START",0.0),
	slice.duration = c("SLICE_DURATION",1.0),
	slice.delta = c("SLICE_DELTA",1.0),
	animate.type = c("ANIMATE_TYPE","cosine animation"),
	slice.end = c("SLICE_END",5),
	layout.type = c("LAYOUT_TYPE","MultiComp KK Layout")
);
#must be a more elegant way to do this..
class(soniaLayoutSettings) <- "sonia.settings";

soniaApplySettings <- list (
	settings.class=c("SettingsClass","sonia.settings.ApplySettings"),
	apply.all = c("APPLY_REMAINING","false"),
	stop.error = c("STOP_ON_ERROR","false"),
	rescale.layout = c("RESCALE_LAYOUT","none"),
	isolate.position = c("ISOLATE_POSITION","ignore isolates"),
	transform.isolate.exclude = c("TRANSFORM_ISOLATE_EXCLUDE","false"),
	transform.recenter = c("RECENTER_TRANSFORM","false"),
	start.coords.type = c("STARTING_COORDS","use random positions"),
	repaint.n = c("LAYOUT_REPAINT_N",0),
	alg.name=c("Algorithm_Name","Multiple component Kamada-Kawai layout"),
	#these values are only for KK, should be a seperate class containing them
	alg.prop.keys = c("ALG_PROP_KEYS","springConst,min epsilon,optimum dist,cool factor,max passes,comp connect value"),
	kk.opt.dist = c("optimum dist",50.0),
	kk.target.epsilon=c("min epsilon",1.0),
	kk.cool.factor=c("cool factor",0.25),
	kk.spring.constant = c("springConst",1.0),
	kk.comp.connect = c("comp connect value",0),
	kk.max.passes = c("max passes",500));
class(soniaApplySettings) <- "sonia.settings";
	
soniaGraphicsSettings <- list(
	settings.class = c("SettingsClass","sonia.settings.GraphicsSettings"),
	arc.trans = c("arc transparency",0.5),
	show.stats = c("show stats","true"),
	anti.alias = c("AntiAlias graphics","true"),
	arrow.style = c("arrow style","none"),
	arc.width.fact = c("arc width factor",0.5),
	arc.labels = c("arc labels","none"),
	ghost.slice = c("ghost previous slice","false"),
	layout.height = c("layout height",350),
	hide.arcs = c("hide arcs","none"),
	hide.nodes = c("hide nodes","none"),
	node.trans = c("node transparency",0.5),
	layout.width = c("layout width",500),
	node.label.cutoff = c("node label cutoff",0.0),
	node.labels = c("show node labels","labels"),
	node.scale.fact = c("node scale factor",0.5),
	flash.event.dur = c("flash new events",0.0));
class(soniaGraphicsSettings) <- "sonia.settings";

soniaBrowseSettings <- list(
settings.class = c("SettingsClass","sonia.settings.BrowsingSettings"),
	render.offset = c("render offset",0),
	num.frames = c("num interpolated frames",30),
	render.dur = c("render duration",1),
	frame.delay = c("frame delay",30));
class(soniaBrowseSettings) <- "sonia.settings";




#find the path to the directory where rSoNIA is installed
rSoniaLoc <- function(){
  for (lib in .libPaths()){
      if (  sum(.packages(all=TRUE,lib.loc=lib)=="rSoNIA")){
        return(paste(lib,"rSoNIA","java","",sep="/"));
      }
  }
  return(NULL);
}
